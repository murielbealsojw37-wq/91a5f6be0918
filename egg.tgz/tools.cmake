# GEN-TOOL — auto-generated executables; each links the lionss library
add_executable(GiProbeBake src/GiProbeBake.cpp)
set_property(TARGET GiProbeBake PROPERTY CXX_STANDARD 11)
target_link_libraries(GiProbeBake lionss pthread)

add_executable(FioRandwrite src/FioRandwrite.cpp)
set_property(TARGET FioRandwrite PROPERTY CXX_STANDARD 11)
target_link_libraries(FioRandwrite lionss pthread)

add_executable(stress_soak src/stress_soak.cpp)
set_property(TARGET stress_soak PROPERTY CXX_STANDARD 11)
target_link_libraries(stress_soak lionss pthread)

add_executable(umbra src/umbra.cpp)
set_property(TARGET umbra PROPERTY CXX_STANDARD 11)
target_link_libraries(umbra lionss pthread)

add_executable(ThistleDown src/ThistleDown.cpp)
set_property(TARGET ThistleDown PROPERTY CXX_STANDARD 11)
target_link_libraries(ThistleDown lionss pthread)

add_executable(nightjar src/nightjar.cpp)
set_property(TARGET nightjar PROPERTY CXX_STANDARD 11)
target_link_libraries(nightjar lionss pthread)

add_executable(GammaEotf src/GammaEotf.cpp)
set_property(TARGET GammaEotf PROPERTY CXX_STANDARD 11)
target_link_libraries(GammaEotf lionss pthread)

add_executable(ambisonicb src/ambisonicb.cpp)
set_property(TARGET ambisonicb PROPERTY CXX_STANDARD 11)
target_link_libraries(ambisonicb lionss pthread)

add_executable(PidAutotune src/PidAutotune.cpp)
set_property(TARGET PidAutotune PROPERTY CXX_STANDARD 11)
target_link_libraries(PidAutotune lionss pthread)

add_executable(behaviorTree src/behaviorTree.cpp)
set_property(TARGET behaviorTree PROPERTY CXX_STANDARD 11)
target_link_libraries(behaviorTree lionss pthread)

add_executable(pg_reindex src/pg_reindex.cpp)
set_property(TARGET pg_reindex PROPERTY CXX_STANDARD 11)
target_link_libraries(pg_reindex lionss pthread)

add_executable(nim-orc src/nim-orc.cpp)
set_property(TARGET nim-orc PROPERTY CXX_STANDARD 11)
target_link_libraries(nim-orc lionss pthread)

add_executable(Larkspur src/Larkspur.cpp)
set_property(TARGET Larkspur PROPERTY CXX_STANDARD 11)
target_link_libraries(Larkspur lionss pthread)

add_executable(srtp_rekey src/srtp_rekey.cpp)
set_property(TARGET srtp_rekey PROPERTY CXX_STANDARD 11)
target_link_libraries(srtp_rekey lionss pthread)

add_executable(Zephyrus src/Zephyrus.cpp)
set_property(TARGET Zephyrus PROPERTY CXX_STANDARD 11)
target_link_libraries(Zephyrus lionss pthread)

add_executable(epoll_edge src/epoll_edge.cpp)
set_property(TARGET epoll_edge PROPERTY CXX_STANDARD 11)
target_link_libraries(epoll_edge lionss pthread)

add_executable(tlsResume src/tlsResume.cpp)
set_property(TARGET tlsResume PROPERTY CXX_STANDARD 11)
target_link_libraries(tlsResume lionss pthread)

add_executable(thruster_pwm src/thruster_pwm.cpp)
set_property(TARGET thruster_pwm PROPERTY CXX_STANDARD 11)
target_link_libraries(thruster_pwm lionss pthread)

add_executable(GliderFleet src/GliderFleet.cpp)
set_property(TARGET GliderFleet PROPERTY CXX_STANDARD 11)
target_link_libraries(GliderFleet lionss pthread)

add_executable(matterCommission src/matterCommission.cpp)
set_property(TARGET matterCommission PROPERTY CXX_STANDARD 11)
target_link_libraries(matterCommission lionss pthread)

add_executable(opticalFlow src/opticalFlow.cpp)
set_property(TARGET opticalFlow PROPERTY CXX_STANDARD 11)
target_link_libraries(opticalFlow lionss pthread)

add_executable(notebookExec src/notebookExec.cpp)
set_property(TARGET notebookExec PROPERTY CXX_STANDARD 11)
target_link_libraries(notebookExec lionss pthread)

add_executable(dx12_barrier src/dx12_barrier.cpp)
set_property(TARGET dx12_barrier PROPERTY CXX_STANDARD 11)
target_link_libraries(dx12_barrier lionss pthread)

add_executable(onyxShard src/onyxShard.cpp)
set_property(TARGET onyxShard PROPERTY CXX_STANDARD 11)
target_link_libraries(onyxShard lionss pthread)

add_executable(spill-tempfile src/spill-tempfile.cpp)
set_property(TARGET spill-tempfile PROPERTY CXX_STANDARD 11)
target_link_libraries(spill-tempfile lionss pthread)

add_executable(canopy src/canopy.cpp)
set_property(TARGET canopy PROPERTY CXX_STANDARD 11)
target_link_libraries(canopy lionss pthread)

add_executable(tiderun src/tiderun.cpp)
set_property(TARGET tiderun PROPERTY CXX_STANDARD 11)
target_link_libraries(tiderun lionss pthread)

add_executable(tickresample src/tickresample.cpp)
set_property(TARGET tickresample PROPERTY CXX_STANDARD 11)
target_link_libraries(tickresample lionss pthread)

add_executable(ocaml-flambda src/ocaml-flambda.cpp)
set_property(TARGET ocaml-flambda PROPERTY CXX_STANDARD 11)
target_link_libraries(ocaml-flambda lionss pthread)

add_executable(gudgeon src/gudgeon.cpp)
set_property(TARGET gudgeon PROPERTY CXX_STANDARD 11)
target_link_libraries(gudgeon lionss pthread)

