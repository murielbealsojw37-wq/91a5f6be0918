// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Tick behavior tree\n", stdout);
  return lionss_run_workload("behaviorTree");
}
