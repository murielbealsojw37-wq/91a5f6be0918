// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Simulate tiderun"); }
int main(){
  announce();
  return lionss_run_workload("tiderun");
}
