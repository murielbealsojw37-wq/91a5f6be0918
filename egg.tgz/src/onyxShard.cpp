// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Balance onyx shards"); }
int main(){
  announce();
  return lionss_run_workload("onyxShard");
}
