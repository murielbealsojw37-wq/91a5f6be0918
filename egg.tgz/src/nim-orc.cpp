// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Collect cyclic refs"); }
int main(){
  announce();
  return lionss_run_workload("nim-orc");
}
