// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Run soak test"); }
int main(){
  announce();
  return lionss_run_workload("stress_soak");
}
